package demo.poc.app.com.myapplication.helper;

/**
 * Created by david zhang on 5/6/2016.
 */
public class SignalInfo {
    public String tradeId;
    public String userId;
    public String side;
    public String symbol;
    public String entryPrice;
    public String minPrice;
    public String maxPrice;
    public String expireDate;
    public String createDate;
    public String lastPrice;
    public String maxGain;
    public String maxLose;
    public String avgGain;
    public String avgLose;
    public String profit;
    public String userNickName;
    public String gainPercent;
    public String score;
    public String chartSrc;

    public SignalInfo(String tradeId, String userId, String side, String symbol, String entryPrice, String minPrice, String maxPrice, String expireDate, String createDate, String lastPrice, String maxGain, String maxLose, String avgGain, String avgLose, String profit, String userNickName, String gainPercent, String score, String chartSrc) {
        this.tradeId = tradeId;
        this.userId = userId;
        this.side = side;
        this.symbol = symbol;
        this.entryPrice = entryPrice;
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
        this.expireDate = expireDate;
        this.createDate = createDate;
        this.lastPrice = lastPrice;
        this.maxGain = maxGain;
        this.maxLose = maxLose;
        this.avgGain = avgGain;
        this.avgLose = avgLose;
        this.profit = profit;
        this.userNickName = userNickName;
        this.gainPercent = gainPercent;
        this.score = score;
        this.chartSrc = chartSrc;
    }
}
